/**
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 */

//Person object set to the global window to be used with main
// person.jobs & person.actions with an array of 4 or more multiple items for each
/*function Person(name,action,job,row){
    this.name = name;
    this.action = action; //Math.floor(Math.random()*person.actions.length) randomly select one item from the Person.actions array
    this.job = job;  //Math.floor(Math.random()*person.jobs.length) randomly select one item from the Person.jobs array
    this.row = row;
}
*/
//display starting action of Person in 3rd column
//add property through prototype called update which is called from the main




