/**
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 */
//var names =[person1, person2, person3, person4, person5];
//var r = Math.floor(Math.random()* 5)  ramdomize a number 0-5
//var randPerson = names[r]; get a random name from the array

//Use for loop to create 3 instances of Person
    //send randPerson to instance
    // place the results in an array called people
    //function populateHTML(){}
        // output the person's name and person's job to .innerHTML
        //if statement to check for duplicate names if found generate another name
//Set up an Interval that calls a runUpdate() function 30 times a second.
    //runUpdate(){}
    //loop through each person to add Person.prototype.update

